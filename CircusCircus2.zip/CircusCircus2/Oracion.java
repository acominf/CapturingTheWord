import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Clase que unifica el SetImage de las clases de opciones, aparte de
 * que diferencía las clases de opciones al resto de clases.
**/
public class Oracion extends Actor
{
    /**
     * Metodo que inserta una imágen en la posición indicada
    **/
    public void SetImage(String name){
        setImage(name);
        setLocation(150,25);
    }
}
