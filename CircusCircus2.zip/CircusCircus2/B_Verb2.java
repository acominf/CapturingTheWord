import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Arreglo de imagenes de respuestas de nivel 2
 * Respuestas 3 (correctas)
**/
public class B_Verb2 extends Puerta
{
    private String []Op3={"run3rR.png","teach3rR.png","think3rR.png","undertake3rR.png","weave3rR.png"};
   
     public void returnImg2(int pos, int x, int y)
    {    
        super.SetImage(Op3[pos],x,y);
    }
}
