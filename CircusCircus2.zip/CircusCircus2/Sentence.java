import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Clase encargada de mostrar en pantalla las clases hijas de
 * puerta y de oracion, se van mostrando de acuerdo a cómo se va respondiendo
 * acomodado en 3 niveles, y aquí se desarrolla la interaccion de las
 * opciones a respuesta con el personaje.
**/
public class Sentence extends Actor
{
    private Return r;
    
    private int band, cont, enable, aux, Obj1, Obj2, x, t;
    private int[] NumAl = new int[5];
    
    private A_English varE1;
    private A_English1 varE2;
    private A_English2 varE3;
    private A_Or_English oracionE;
    
    private B_Verb varV1;
    private B_Verb1 varV2;
    private B_Verb2 varV3;
    private B_Or_Verb oracionV;
    
    private C_Phrasal varP1;
    private C_Phrasal1 varP2;
    private C_Phrasal2 varP3;
    private C_Or_Phrasal oracionP;
   
    public Sentence(Return ret){
        r=ret;
        band=cont=enable=x=t=0;
        aux=1;
        
        varE1=new A_English();
        varE2=new A_English1();
        varE3=new A_English2();
        oracionE=new A_Or_English();
        
        varV1= new B_Verb();
        varV2= new B_Verb1();
        varV3= new B_Verb2();
        oracionV=new B_Or_Verb();
        
        varP1= new C_Phrasal();
        varP2= new C_Phrasal1();
        varP3= new C_Phrasal2();
        oracionP=new C_Or_Phrasal();
        
        for(int n=0;n<5;n++){   
            NumAl[n]=n;
        }
        
        for(int n=0;n<5;n++){       //Para que se cree de manera aleatoria la forma de mostrar las oraciones y las puertas
            x=getRandomNumber(0,4);
            t=NumAl[n];
            NumAl[n]=NumAl[x];
            NumAl[x]=t;
        }
    }
    
     /**
     * Metodo donde se desarrollan los niveles que va pasando el Personaje
    **/
    public void act(){
        switch(aux){
            case 1: aux = nivel1(); break;
            case 2: aux = nivel2(); break;
            case 3: aux = nivel3(); break;
            case 4: r.stopSound(); Greenfoot.setWorld(new Winner()); break;
       }
    }
    
    /**
     * Método que indica el desarrollo de cómo se van mostrando las opciones y las respectivas respuestas,
     * aquí se mantiene un orden para que no muestre opciones que no van con la pregunta. Es la misma lógica
     * que se usó para los 3 niveles, lo que cambia son las imágenes que se muestran.
    **/
    public int nivel1(){
        World myWorld = getWorld();
        MyWorld MyWorld = (MyWorld)myWorld;
        Counter counter = MyWorld.getCounter();
        int au=1; 
        if(enable==0){
            getWorld().addObject(new Nivel(1),50,475);
            getWorld().addObject(oracionE,150,25);
            oracionE.returnOrc(NumAl[cont]);
            getWorld().addObject(varE1,getRandomNumber(50,750),getRandomNumber(150,350));
            varE1.returnImg(NumAl[cont],getRandomNumber(50,750),getRandomNumber(150,350));
            getWorld().addObject(varE2,getRandomNumber(50,750),getRandomNumber(150,350));
            varE2.returnImg1(NumAl[cont],getRandomNumber(50,750),getRandomNumber(150,350));
            getWorld().addObject(varE3,getRandomNumber(50,750),getRandomNumber(150,350));
            varE3.returnImg2(NumAl[cont],getRandomNumber(50,750),getRandomNumber(150,350));
            enable=1;
        }
        if(Obj1==0){
            if(varE1.canSee(Personaje.class)){
                getWorld().removeObject(varE1);
                Obj1=1;
                counter.quitScore();
            }
        }
        if(Obj2==0){
            if(varE2.canSee(Personaje.class)){
                getWorld().removeObject(varE2);
                Obj2=1;
                counter.quitScore();
            }
        }
        if(cont<4){    
            if(varE3.canSee(Personaje.class)){
                cont++;
                oracionE.returnOrc(NumAl[cont]);
                counter.addScore();
                if(Obj1==1){
                    getWorld().addObject(varE1,getRandomNumber(50,750),getRandomNumber(150,350));
                    Obj1=0;
                }
                if(Obj2==1){
                    getWorld().addObject(varE2,getRandomNumber(50,750),getRandomNumber(150,350));
                    Obj2=0;
                }
                varE1.returnImg(NumAl[cont],getRandomNumber(50,750),getRandomNumber(150,350));
                varE2.returnImg1(NumAl[cont],getRandomNumber(50,750),getRandomNumber(150,350));
                varE3.returnImg2(NumAl[cont],getRandomNumber(50,750),getRandomNumber(150,350));
            }
        }
        else{
            if(varE3.canSee(Personaje.class)){
                if(cont>=4){
                   cont++;
                   if(cont==10){
                       counter.addScore();
                       getWorld().removeObject(varE1);
                       getWorld().removeObject(varE2);
                       getWorld().removeObject(varE3);
                       au = 2;
                       cont=Obj1=Obj2=enable=0;
                   }
                }
            }
        }
        return(au);
    }
    
    public int nivel2(){
        int au=2; 
        World myWorld = getWorld();
        MyWorld MyWorld = (MyWorld)myWorld;
        Counter counter = MyWorld.getCounter();
        if(enable==0){
            getWorld().addObject(new Nivel(2),50,475);
            getWorld().addObject(oracionV,150,25);
            oracionV.returnOrc(NumAl[cont]);
            getWorld().addObject(varV1,getRandomNumber(50,750),getRandomNumber(150,350));
            varV1.returnImg(NumAl[cont],getRandomNumber(50,750),getRandomNumber(150,350));
            getWorld().addObject(varV2,getRandomNumber(50,750),getRandomNumber(150,350));
            varV2.returnImg1(NumAl[cont],getRandomNumber(50,750),getRandomNumber(150,350));
            getWorld().addObject(varV3,getRandomNumber(50,750),getRandomNumber(150,350));
            varV3.returnImg2(NumAl[cont],getRandomNumber(50,750),getRandomNumber(150,350));
            enable=1;
        }
        if(Obj1==0){
            if(varV1.canSee(Personaje.class)){
                getWorld().removeObject(varV1);
                Obj1=1;
                counter.quitScore();
            }
        }
        if(Obj2==0){
            if(varV2.canSee(Personaje.class)){
                getWorld().removeObject(varV2);
                Obj2=1;
                counter.quitScore();
            }
        }
        if(cont<4){    
            if(varV3.canSee(Personaje.class)){
                cont++;
                oracionV.returnOrc(NumAl[cont]);
                counter.addScore();
                if(Obj1==1){
                    getWorld().addObject(varV1,getRandomNumber(50,750),getRandomNumber(150,350));
                    Obj1=0;
                }
                if(Obj2==1){
                    getWorld().addObject(varV2,getRandomNumber(50,750),getRandomNumber(150,350));
                    Obj2=0;
                }
                varV1.returnImg(NumAl[cont],getRandomNumber(50,750),getRandomNumber(150,350));
                varV2.returnImg1(NumAl[cont],getRandomNumber(50,750),getRandomNumber(150,350));
                varV3.returnImg2(NumAl[cont],getRandomNumber(50,750),getRandomNumber(150,350));
            }
        }
        else{
            if(varV3.canSee(Personaje.class)){
                if(cont>=4){
                   cont++;
                   if(cont==10){
                       counter.addScore();
                       getWorld().removeObject(varV1);
                       getWorld().removeObject(varV2);
                       getWorld().removeObject(varV3);
                       au = 3;
                       cont=Obj1=Obj2=enable=0;
                   }
                }
            }
        }
        return(au);
    }
    
    public int nivel3(){
        World myWorld = getWorld();
        MyWorld MyWorld = (MyWorld)myWorld;
        Counter counter = MyWorld.getCounter();
        int au=3; 
        if(enable==0){
            getWorld().addObject(new Nivel(3),50,475);
            getWorld().addObject(oracionP,150,25);
            oracionP.returnOrc(NumAl[cont]);
            getWorld().addObject(varP1,getRandomNumber(50,750),getRandomNumber(150,350));
            varP1.returnImg(NumAl[cont],getRandomNumber(50,750),getRandomNumber(150,350));
            getWorld().addObject(varP2,getRandomNumber(50,750),getRandomNumber(150,350));
            varP2.returnImg1(NumAl[cont],getRandomNumber(50,750),getRandomNumber(150,350));
            getWorld().addObject(varP3,getRandomNumber(50,750),getRandomNumber(150,350));
            varP3.returnImg2(NumAl[cont],getRandomNumber(50,750),getRandomNumber(150,350));
            enable=1;
        }
        if(Obj1==0){
            if(varP1.canSee(Personaje.class)){
                getWorld().removeObject(varP1);
                Obj1=1;
                counter.quitScore();
            }
        }
        if(Obj2==0){
            if(varP2.canSee(Personaje.class)){
                getWorld().removeObject(varP2);
                Obj2=1;
                counter.quitScore();
            }
        }
        if(cont<4){    
            if(varP3.canSee(Personaje.class)){
                cont++;
                oracionP.returnOrc(NumAl[cont]);
                counter.addScore();
                if(Obj1==1){
                    getWorld().addObject(varP1,getRandomNumber(50,750),getRandomNumber(150,350));
                    Obj1=0;
                }
                if(Obj2==1){
                    getWorld().addObject(varP2,getRandomNumber(50,750),getRandomNumber(150,350));
                    Obj2=0;
                }
                varP1.returnImg(NumAl[cont],getRandomNumber(50,750),getRandomNumber(150,350));
                varP2.returnImg1(NumAl[cont],getRandomNumber(50,750),getRandomNumber(150,350));
                varP3.returnImg2(NumAl[cont],getRandomNumber(50,750),getRandomNumber(150,350));
            }
        }
        else{
            if(varP3.canSee(Personaje.class)){
                if(cont>=4){
                   cont++;
                   if(cont==10){
                       counter.addScore();
                       getWorld().removeObject(varP1);
                       getWorld().removeObject(varP2);
                       getWorld().removeObject(varP3);
                       au=4;
                       cont=Obj1=Obj2=enable=0;
                   }
                }
            }
        }
        return(au);
    }
    
    /**
     * Obtiene numeros random 
    **/
    public int getRandomNumber(int start, int end) 
    {
        return Greenfoot.getRandomNumber(end-start+1) + start;
    }
}
