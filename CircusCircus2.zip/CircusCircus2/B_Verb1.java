import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Arreglo de imagenes de respuestas de nivel 2
 * Respuestas 2 (incorrectas)
**/
public class B_Verb1 extends Puerta
{
    private String []Op2={"run2r.png","teach2r.png","think2r.png","undertake2r.png","weave2r.png"};

     public void returnImg1(int pos, int x, int y)
    {    
        super.SetImage(Op2[pos],x,y);
    } 
}
