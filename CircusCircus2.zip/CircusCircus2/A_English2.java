import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Arreglo de imagenes de respuestas de nivel 1
 * Respuestas 3 (correctas)
**/
public class A_English2 extends Puerta
{
    private String []Op3={"Appliance3rR.png","Disrepute3rR.png","Largesse3rR.png","Manners3rR.png","Within3rR.png"};
 
     public void returnImg2(int pos, int x, int y)
    {    
        super.SetImage(Op3[pos],x,y);
    }
}
