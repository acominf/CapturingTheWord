import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Enemigo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public abstract class Enemigo extends Monito
{
    /**
     * 
     **/
    public void act() 
    {
        //
    }
    
    /**
     * 
     **/
    public int getRandomNumber(int start, int end) 
    {
        return Greenfoot.getRandomNumber(end-start+1) + start;
    }
}
