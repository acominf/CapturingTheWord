import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Imagen que se muestra para 
 * el jugador cuando gana el juego.
 */
public class Winner extends World
{
    public Winner()
    {    
        super(800, 500, 1);
        addObject(new Return(1),750,470);
    }
}
