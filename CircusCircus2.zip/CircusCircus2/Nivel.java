import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Muestra visualmente en el nivel que se encuentra el Personaje
 */
public class Nivel extends Actor
{
    private int nivel;
    
    public Nivel(int num){
        nivel=num;
    }

    public void act() 
    {
        setImage(new GreenfootImage("Nivel: " + nivel, 25 , Color.RED, Color.BLACK));
    }    
}
