import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Contador de puntos de personaje.
 * Agrega puntos al escoger la puerta correcta 
 * en caso contrario los quita.
**/
public class Counter extends Actor
{
    int score = 0;
    
    /**
     * Metodo que inserta visualmente los puntos obtenidos
    **/
    public void act() 
    {
        setImage(new GreenfootImage("Score : " + score, 25 , Color.RED, Color.BLACK));
    }
    
    /**
     * Metodo que suma el puntuaje
    **/
    public void addScore(){
        score++;
    }
    
    /**
     * Metodo que resta el puntuaje
    **/
    public void quitScore(){
        score--;
    }
}
