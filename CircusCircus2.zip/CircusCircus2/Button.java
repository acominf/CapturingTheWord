import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Clase creada con el fin de mantener un orden de los botones y
 * que se diferencíen de las demás clases
 */
public class Button extends Actor
{}
