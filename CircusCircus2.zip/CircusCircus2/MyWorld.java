import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Mundo donde se encuentra el juego.
 * Se crea un contador de puntos
 * y los objetos que estaran en el juego.
 * Se manda el botón return a las clases 
 * para que se pueda controlar el sonido
 * desde otras clases.
**/
public class MyWorld extends World
{
    Counter counter = new Counter();
    Return ret = new Return(0);
    
    /**
     * Constructor for objects of class MyWorld.
    **/
    public MyWorld()
    {    
        // Create a new world with 800x500 cells with a cell size of 1x1 pixels.
        super(800, 500, 1);
        addObject(new Sentence(ret),800,500);
        addObject(counter, 450,25);
        addObject(new Personaje(ret),200,200);
        addObject(ret,750,470);
    }
    
    public Counter getCounter(){
        return counter;
    }
}
