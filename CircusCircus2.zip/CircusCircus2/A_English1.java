import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Arreglo de imagenes de respuestas de nivel 1
 * Respuestas 2 (incorrectas)
**/
public class A_English1 extends Puerta
{
    private String []Op2={"Appliance2r.png","Disrepute2r.png","Largesse2r.png","Manners2r.png","Within2r.png"};

     public void returnImg1(int pos, int x, int y)
    {    
        super.SetImage(Op2[pos],x,y);
    }
}
