import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Boton que manda al mundo de Background(inicio donde encontramos 
 * todas las demas opciones), aparte de controlar el sonido desde
 * todas las clases en las que se implementa.
 */
public class Return extends Button
{
    GreenfootSound song = new GreenfootSound("CC.wav");
    private int enable;
    
    /**
     * Recibe un valor entero, el cuál sirve como habilitador si se requiere sonido
     * en la clase o no.
    **/
    public Return(int num){
        enable=num;
    }
    
    /**
     * Método en donde se controla la acción del botón, si la habilitación es 0, se reproduce el sonido,
     * si se presiona entonces manda al mundo inicial y se detiene el sonido.
    **/
    public void act() 
    {
        if(enable==0){
            song.playLoop();
            enable=1;
        }
        
        if (Greenfoot.mouseClicked(this)){
            if(song.isPlaying()){
                song.stop();
            }
            Greenfoot.setWorld(new Background());
        }
    }
    
    public void stopSound(){
        song.stop();
    }
}
