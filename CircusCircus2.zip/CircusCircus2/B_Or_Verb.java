import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Clase que muestra las palabras a traducir del nivel 2
 */
public class B_Or_Verb extends Oracion
{
    private String []name={"run.png","teach.png","think.png","undertake.png","weave.png"};
    
    public void returnOrc(int pos){
        super.SetImage(name[pos]);
    }
}
