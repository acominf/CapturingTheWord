import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Enemigo de Personaje el cual se mueve de
 * izquierda a derecha en el eje X
**/
public class Chango extends Monito
{
    private GreenfootImage monkey1;
    private GreenfootImage monkey2;
    private int x,y,randY;
    
    public Chango()
    {
        monkey1 = new GreenfootImage("monkey1.png");
        monkey2 = new GreenfootImage("monkey2.png");
    }
    
    /**
     * Metodo el cual ejecuta el movimiento 
     * horizontal del chango
    **/
    public void act() 
    {
        x=getX();
        y=getY();
        if(getImage()==monkey1)
            setImage(monkey2);
        else
            setImage(monkey1);
        setLocation(x+5,y);
        if(isAtEdge()){
            randY=getRandomNumber(80,420);
            if(randY!=y)
                setLocation(0,randY);
        }
    }    
}
