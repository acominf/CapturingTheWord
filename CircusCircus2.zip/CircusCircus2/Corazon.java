import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Muestra visualmente las vidas
 */
public class Corazon extends Actor
{}
