import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Muestra here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Muestra extends Actor
{
    String texto = "";
    ArchivoMuestra ayuda;
    int band = 0;
    public Muestra(){
        ayuda= new ArchivoMuestra();
    }
    public void act() 
    {
        texto = ayuda.leerTextoArchivo();
        if(band == 0)
            show();
        band=1; 
    }  
    public void show(){
        setImage(new GreenfootImage(texto, 25 , Color.WHITE, Color.BLACK));
    } 
}
