import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Clase que muestra las palabras a traducir del nivel 1
 */
public class A_Or_English extends Oracion
{
    private String []name={"appliance.png","disrepute.png","largesse.png","manners.png","within.png"};
    
    public void returnOrc(int pos){
        super.SetImage(name[pos]);
    }
}
