import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Imagen que se muestra para 
 * el jugador cuando pierde las vidas.
**/
public class GameOver extends World
{
    public GameOver()
    {    
        super(800, 500, 1);
        addObject(new Return(1),750,470);
    }
}
