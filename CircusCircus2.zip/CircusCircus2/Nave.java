import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Nave here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Nave extends Enemigo
{
    private GreenfootImage nave;
    private int x,y,randX;
    /**
     * 
    **/
    public Nave() 
    {
        nave = new GreenfootImage("nave.png");
    }    
    /**
     * 
    **/
    public void act() 
    {
        x=getX();
        y=getY();
        setLocation(x,y+8);
        if(isAtEdge()){
            randX=getRandomNumber(0,800);
            if(randX!=x)
                setLocation(randX,80);
        }
    }    
}
