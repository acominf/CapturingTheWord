import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Enemigo de Personaje el cual se mueve de
 * izquierda a derecha en el eje X
**/
public class Nave extends Monito
{
    private GreenfootImage nave;
    private int x,y,randX;
    
    public Nave() 
    {
        nave = new GreenfootImage("nave.png");
    }    
    
    /**
     * Metodo el cual ejecuta el movimiento 
     * vertical de la nave
    **/
    public void act() 
    {
        x=getX();
        y=getY();
        setLocation(x,y+5);
        if(y>=440){
            randX=getRandomNumber(0,800);
            if(randX!=x)
                setLocation(randX,80);
        }
    }    
}
