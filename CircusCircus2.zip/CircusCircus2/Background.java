import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Fondo principal con su imagen al iniciar el juego
 * con sus respectivas opciones.
 */
public class Background extends World
{
    public Background()
    {    
        super(800, 500, 1);
        addObject(new Start(),570,90);
        addObject(new Help(),510,200);
        addObject(new Credits(),480,330);
    }
 }
