import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Imagen que muestra la ayuda al jugador.
 */
public class Ayuda extends World
{
    public Ayuda()
    {    
       super(800, 500, 1); 
       addObject(new Muestra(),400,250);
       addObject(new Return(1),750,470);
    }
}
