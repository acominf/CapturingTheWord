import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Arreglo de imagenes de respuestas de nivel 1
 * Respuestas 1 (incorrectas)
**/
public class A_English extends Puerta
{  
    private String []Op1={"Appliance1r.png","Disrepute1r.png","Largesse1r.png","Manners1r.png","Within1r.png"};

    public void returnImg(int pos, int x, int y)
    {    
        super.SetImage(Op1[pos],x,y);
    }
}