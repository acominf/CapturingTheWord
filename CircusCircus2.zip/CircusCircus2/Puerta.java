import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Clase que unifica las respuestas de las oraciones
**/
public abstract class Puerta extends Actor
{
    /**
     * Clase que devuelve un verdadero o falso si el objeto está en contacto
     * con el objeto que se recibe como parámetro.
    **/
    public boolean canSee(Class clss)
    {
        Actor actor = getOneObjectAtOffset(0, 0, clss);
        return actor != null;        
    }
    
    /**
     * Metodo que inserta una imágen en la posición indicada
    **/
    public void SetImage(String name, int x, int y){
        setImage(name);
        setLocation(x,y);
    }
}
