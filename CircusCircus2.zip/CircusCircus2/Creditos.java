import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Imagen que se muestra para los creditos
 * a los autores del juego.
 */
public class Creditos extends World
{
   Creditos()
    {    
        super(800, 500, 1); 
        addObject(new Return(1),750,470);
    }
}
