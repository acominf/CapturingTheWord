import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Clase que muestra las palabras a traducir del nivel 3
 */
public class C_Or_Phrasal extends Oracion
{
    private String []name={"back up.png","get by.png","iron out.png","turn out.png","walk out.png"};
    
    public void returnOrc(int pos){
        super.SetImage(name[pos]);
    }
}
