import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import greenfoot.*;  
public class ArchivoMuestra{
  /**
   * En este método se abre un archivo de texto, lo concatena en una
   * variable String y lo regresa.
  **/
  public String leerTextoArchivo() {
    String texto = "";
    FileReader archivo = null;
    String linea = "";
    try {
      archivo = new FileReader("Ayuda.txt");
      BufferedReader lector = new BufferedReader(archivo);
      while ((linea = lector.readLine()) != null) {
        texto += linea + "\n";
      }
    } catch (FileNotFoundException e) {
      throw new RuntimeException("Archivo no encontrado");
    } catch (IOException e) {
      throw new RuntimeException("Ocurrio un error de entrada/salida");
    } finally {
      if (archivo != null) {
        try {
          archivo.close();
        } catch (IOException e) {
          e.printStackTrace();
        }
      }
    }
    return texto;
  }
}