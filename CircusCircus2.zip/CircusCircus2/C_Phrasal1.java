import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Arreglo de imagenes de respuestas de nivel 3
 * Respuestas 2 (incorrectas)
**/
public class C_Phrasal1 extends Puerta
{
    private String []Op2={"backUp2r.png","getby2r.png","ironout2r.png","turnout2r.png","walkout2r.png"};

     public void returnImg1(int pos, int x, int y)
    {    
        super.SetImage(Op2[pos],x,y);
    }
}
