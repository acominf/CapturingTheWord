import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo
/**
 * Arreglo de imagenes de respuestas de nivel 3
 * Respuestas 1 (incorrectas)
**/
public class C_Phrasal extends Puerta
{   
    private String []Op1={"backUp1r.png","getby1r.png","ironout1r.png","turnout1r.png","walkout1r.png"};

    public void returnImg(int pos, int x, int y)
    {    
        super.SetImage(Op1[pos],x,y);
    }
}
