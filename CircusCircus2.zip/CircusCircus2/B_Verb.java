import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Arreglo de imagenes de respuestas de nivel 2
 * Respuestas 1 (incorrectas)
**/
public class B_Verb extends Puerta
{
    private String []Op1={"run1r.png","teach1r.png","think1r.png","undertake1r.png","weave1r.png"};

    public void returnImg(int pos, int x, int y)
    {    
        super.SetImage(Op1[pos],x,y);
    }
}
