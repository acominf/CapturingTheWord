import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Personaje here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Personaje extends Monito
{
    private GreenfootImage sideR1;
    private GreenfootImage sideR2;
    private GreenfootImage sideL1;
    private GreenfootImage sideL2;
    private GreenfootImage front1;
    private GreenfootImage front2;
    private GreenfootImage back1;
    private GreenfootImage back2;
    private int x,y;
    /**
     * 
    **/
    public Personaje()
    {
        sideR1 = new GreenfootImage("sideR1.png");
        sideR2 = new GreenfootImage("sideR2.png");
        sideL1 = new GreenfootImage("sideL1.png");
        sideL2 = new GreenfootImage("sideL2.png");
        front1 = new GreenfootImage("front1.png");
        front2 = new GreenfootImage("front2.png");
        back1 = new GreenfootImage("back1.png");
        back2 = new GreenfootImage("back2.png");
    }
    
    /**
     * 
    **/
    public void act() 
    {
        x=getX();
        y=getY();
        if(Greenfoot.isKeyDown("right"))   //Move in right side
            {
             if(getImage()==sideR1)
                setImage(sideR2);
             else
                setImage(sideR1);
             if(x<780)
                setLocation(x+3,y);
            }
        else
            if(Greenfoot.isKeyDown("left"))
            {                  
                if(getImage()==sideL1)
                    setImage(sideL2);
                else
                    setImage(sideL1);
                if(x>28)
                    setLocation(x-3,y);                   
             }
             else 
                if(Greenfoot.isKeyDown("up"))
                {
                    if(getImage()==back1)
                        setImage(back2);
                    else
                        setImage(back1);
                    if(y>80)
                        setLocation(x,y-3);                         
                    } 
                else
                    if(Greenfoot.isKeyDown("down"))
                    {                            
                        if(getImage()==front1)
                            setImage(front2);
                        else
                             setImage(front1);
                        if(y<411)
                             setLocation(x,y+3);                                  
                    }
    }
}
