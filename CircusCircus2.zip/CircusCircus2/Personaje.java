import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * En esta clase se hacen los movimientos de monito
 * sus diferentes sprites, se crean tambien los enemigos para
 * tener un control al momento de utilizar el metodo canSee
 * y se lleva tambien el conteo de las vidas.
**/
public class Personaje extends Monito
{
    private Return r;
    
    private GreenfootImage sideR1;
    private GreenfootImage sideR2;
    private GreenfootImage sideL1;
    private GreenfootImage sideL2;
    private GreenfootImage front1;
    private GreenfootImage front2;
    private GreenfootImage back1;
    private GreenfootImage back2;
    
    private Chango ch1, ch2;
    private Nave nv1, nv2;
    private Actor aux, aux2, aux3, aux4;
    private Corazon cor[];
    
    private int x,y,vidas,enable,Ech1,Ech2,xv;
    
    public Personaje(Return ret)
    {
        r=ret;
        sideR1 = new GreenfootImage("sideR1.png");
        sideR2 = new GreenfootImage("sideR2.png");
        sideL1 = new GreenfootImage("sideL1.png");
        sideL2 = new GreenfootImage("sideL2.png");
        front1 = new GreenfootImage("front1.png");
        front2 = new GreenfootImage("front2.png");
        back1 = new GreenfootImage("back1.png");
        back2 = new GreenfootImage("back2.png");
        ch1 = new Chango();
        ch2 = new Chango();     // se crean los enemigos
        nv1 = new Nave();
        nv2 = new Nave();
        cor = new Corazon[5];
        xv=750;        
        for(int n=0;n<5;n++)        //Se crean los corazones 
            cor[n]=new Corazon();
        enable=0;
    }
    
    /**
     * Metodo en el cual se hacen los movimientos de monito
     * y la forma en que se relaciona con los otros objetos
    **/
    public void act() 
    {
        x=getX();
        y=getY();
        if(enable==0){
            getWorld().addObject(ch1,0,300);
            getWorld().addObject(ch2,0,100);
            getWorld().addObject(nv1,250,80);
            getWorld().addObject(nv2,100,80);
            for(int n=0;n<5;n++){
                getWorld().addObject(cor[n],xv,25);
                xv-=50;
            }
            vidas=5;
            enable=1;
        }
        if(Greenfoot.isKeyDown("right"))   //Move in right side
            {
             if(getImage()==sideR1)
                setImage(sideR2);
             else
                setImage(sideR1);
             if(x<780)
                setLocation(x+3,y);
            }
        else
            if(Greenfoot.isKeyDown("left"))
            {                  
                if(getImage()==sideL1)
                    setImage(sideL2);
                else
                    setImage(sideL1);
                if(x>28)
                    setLocation(x-3,y);  
             }
             else 
                if(Greenfoot.isKeyDown("up"))
                {
                    if(getImage()==back1)
                        setImage(back2);
                    else
                        setImage(back1);
                    if(y>80)
                        setLocation(x,y-3);  
                    } 
                else
                    if(Greenfoot.isKeyDown("down"))
                    {                            
                        if(getImage()==front1)
                            setImage(front2);
                        else
                             setImage(front1);
                        if(y<411)
                             setLocation(x,y+3);  
                    }
        if(canSee(Chango.class)){
            aux = getOneIntersectingObject(Chango.class);
            aux2=aux;
            getWorld().removeObject(aux);
            getWorld().addObject(aux2,0,getRandomNumber(80,420));
            vidas--;
            getWorld().removeObject(cor[vidas]);
        }
        if(canSee(Nave.class)){
            aux3 = getOneIntersectingObject(Nave.class);
            aux4=aux3;
            getWorld().removeObject(aux3);
            getWorld().addObject(aux4,getRandomNumber(0,800),80);
            vidas--;
            getWorld().removeObject(cor[vidas]);
        }
        if(vidas == 0){
            r.stopSound();
            Greenfoot.setWorld(new GameOver());
        }
    }
}
