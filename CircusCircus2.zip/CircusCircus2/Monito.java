import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Clase abstracta monito con metodos generales
 * que las demás emplean.
**/
public abstract class Monito extends Actor
{    
    /**
     * Clase que devuelve un verdadero o falso si el objeto está en contacto
     * con el objeto que se recibe como parámetro.
    **/
    public boolean canSee(Class clss)
    {
        Actor actor = getOneObjectAtOffset(0, 0, clss);
        return actor != null;        
    }
    
    /**
     * Clase que devuelve un numero random entre un límite establecido.
    **/
    public int getRandomNumber(int start, int end) 
    {
        return Greenfoot.getRandomNumber(end-start+1) + start;
    }
}
